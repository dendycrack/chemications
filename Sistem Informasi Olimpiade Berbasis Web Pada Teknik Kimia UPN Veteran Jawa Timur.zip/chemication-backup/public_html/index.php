<?php
ini_set('display_errors',1);
require_once('../app/init.php');
/*
    Struktur kode saat ini:
        App.php
        Controller.php
        init.php
        index.php
*/

$app = new App;

/*
    Algoritma:
        - index.php membuat instance dari App.php
*/
