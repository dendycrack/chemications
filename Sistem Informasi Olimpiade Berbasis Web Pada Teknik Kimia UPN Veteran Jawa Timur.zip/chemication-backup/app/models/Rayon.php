<?php

class Rayon extends Model{

    protected $table = 'rayon';

}