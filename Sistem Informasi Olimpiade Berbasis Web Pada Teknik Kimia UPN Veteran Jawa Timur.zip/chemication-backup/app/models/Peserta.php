<?php

class Peserta extends Model{

    protected $table = 'peserta';

}