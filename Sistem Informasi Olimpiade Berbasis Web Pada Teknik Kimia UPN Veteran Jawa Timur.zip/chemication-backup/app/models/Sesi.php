<?php

class Sesi extends Model{

    protected $table = 'sesi';

}