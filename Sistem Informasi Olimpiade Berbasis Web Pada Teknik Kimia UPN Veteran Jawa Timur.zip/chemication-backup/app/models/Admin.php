<?php

class Admin extends Model{

    protected $table = 'admin';

}