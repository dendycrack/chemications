<?php

class Activation extends Model{

    protected $table = 'aktivasi';

}