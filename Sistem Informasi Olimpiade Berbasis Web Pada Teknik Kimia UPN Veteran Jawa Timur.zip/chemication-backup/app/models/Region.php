<?php

class Region extends Model{

    protected $table = 'region';

}