<?php

class Soal extends Model{

    protected $table = 'soal';

}