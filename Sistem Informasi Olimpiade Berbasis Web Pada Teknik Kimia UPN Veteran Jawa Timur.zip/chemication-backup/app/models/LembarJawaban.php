<?php

class LembarJawaban extends Model{

    protected $table = 'lembar_jawab';

}