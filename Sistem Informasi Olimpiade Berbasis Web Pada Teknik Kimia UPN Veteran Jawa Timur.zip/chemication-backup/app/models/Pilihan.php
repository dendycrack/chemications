<?php

class Pilihan extends Model{

    protected $table = 'pilihan';

}