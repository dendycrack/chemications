<?php

class Paket extends Model{

    protected $table = 'paket';

}