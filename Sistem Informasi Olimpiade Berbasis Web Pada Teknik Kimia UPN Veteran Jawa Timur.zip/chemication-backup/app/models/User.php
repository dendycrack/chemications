<?php

class User extends Model{

    protected $table = 'user';

}