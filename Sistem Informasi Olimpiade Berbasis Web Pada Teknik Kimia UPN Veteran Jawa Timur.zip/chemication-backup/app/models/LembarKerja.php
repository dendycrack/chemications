<?php

class LembarKerja extends Model{

    protected $table = 'lembar_kerja';

}