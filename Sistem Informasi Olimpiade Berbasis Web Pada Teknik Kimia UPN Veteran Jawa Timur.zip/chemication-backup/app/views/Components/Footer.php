<style>
    #page-footer{
        background-color: #0C203F;
        color: #eee;
        font-size: 10px;
    }
    #page-footer>.container-fluid{
        padding: 20px;
    }
</style>
<div id="page-footer" class="text-center">
    <div class="container-fluid">
        Copyright 2017 - HIMATEKK UPN "Veteran" Jawa Timur
    </div>
</div>
